/*
CSE332 Project 1
Md. Belal Uddin   			1420132042
Jahid Hassan      			1420188042
Mohammad Mahadi Hossain		1421281042
Raiyhan Bhuiyan				1410100642

This project translate assembly to machine language and convert the machine language to HexaDecimal value
Limitation:
For Itype
1)Constant value must be -8 to 7 and constant value does not contain any alphabet else it's throw exception
2)have one Opcode, two register and one constant
3)format: [Opcode registerName1,registerName2,constatnt]

For Rtype:
1)have one opcode, three register
2)format: [Opcode regName1,regName2,regName3


*/
import java.util.ArrayList;

public class Test {
	public String ConvertToBinary(String s)
	{
		Register reg = new Register();
		InstructionList ins = new InstructionList();
		
		
		//split string using regular expression
		String word[] = s.split("\\s");
		
		if(ins.containRtypeInstuction(word[0]))//check is it Rtype.. if Rtype it return true
		{
			
		String mes =null;
		boolean allOk=true;//boolean variable to determine single instruction is correct or not
		mes=ins.getValueOfRtypeInstruction(word[0]);
		
		String register[] = word[1].split(",");
			for(String re:register)
			{
				if(reg.ContainRegister(re))
				{
					mes+=reg.getValueOfRegister(re);
				}
			
				else {
					//System.out.println("Invalid Register Name: "+ re);
					//System.out.println("Register name should be: $zero or [$t0-$t5] or [$s0-$s8]");
					allOk = false;
					return "Invalid Register Name";
					
				}
			
			}
			if(allOk) return mes;;
		}//end of RtypeInstruction
		
		else if(ins.containItypeInstuction(word[0]))
		{
			String mes =null;
			boolean allOk=true;
			mes=ins.getValueOfItypeInstruction(word[0]);
			
			String register[] = word[1].split(",");
				for(String re:register)
				{
					if(reg.ContainRegister(re))
					{
						mes+=reg.getValueOfRegister(re);
					}
					else if(Integer.parseInt(re)>=-8 && Integer.parseInt(re)<=7)//check the value of constan
							{
								String constant = Integer.toBinaryString(Integer.parseInt(re));
								//System.out.println(constant);
								//System.out.println(re);
								if(Integer.parseInt(re)>=0)
								{
									if(constant.length()==1) constant="000"+constant;
									else if(constant.length()==2) constant="00"+constant;
									else if (constant.length()==3) constant = "0"+constant;
									else
										System.out.println("");
									mes+=constant;
									
								}
								if(Integer.parseInt(re)<0)
								{
									String maliha = constant.substring(28, 32);
									//System.out.println(maliha);
									mes+=maliha;
								}
								
								
							}
					else {
						//System.out.println("Invalid Register Name: "+ re);
						//System.out.println("Register name should be: $zero or [$t0-$t5] or [$s0-$s8]");
						allOk = false;
						return "Invalid register or constant Value"+re;
					}
				
				}
				if(allOk) return mes;	
		}
		else
			return "wrong instruction";
		
		return "";
		
		
		
	}
	
	public String ConvertToHexadecimal(String Binary)
	{
		int decimal = Integer.parseInt(Binary,2);
		String hexStr = Integer.toString(decimal,16);
		return hexStr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
	Test t = new Test();
	InstructionFetch instruction = new InstructionFetch("AssemblyLanguage.txt");
	ArrayList<String> inst = new ArrayList<String>();
	inst=instruction.getInstruction();
	
	
	//print Machine code to console
	System.out.println("Machine Language of instructions");
	for(String w:inst)
	{
		System.out.println(t.ConvertToBinary(w));
	}
	System.out.println("");
	System.out.println("Hexa Decimal Value of Machine Language");
	//print Hexa Decimal Value to console
	for(String w:inst)
	{
		
		String Binary = t.ConvertToBinary(w);
		try{
		System.out.println(t.ConvertToHexadecimal(Binary));
		}catch(Exception ex)
		{
			System.out.println("invalid Register Name");
		}
	}
	
	}

}
