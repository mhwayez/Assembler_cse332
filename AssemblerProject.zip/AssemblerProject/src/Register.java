import java.util.HashMap;
import java.util.Map;

public class Register {

	private Map<String, String> registerName;
	
	Register()
	{
		registerName = new HashMap<String, String>();
		
		registerName.put("$Zero","0000");
		//name of tempory register and assign value
		registerName.put("$t0","0001");
		registerName.put("$t1","0010");
		registerName.put("$t2","0011");
		registerName.put("$t3","0100");
		registerName.put("$t4","0101");
		registerName.put("$t5","0110");
		//name of save register and assign value
		registerName.put("$s0","0111");
		registerName.put("$s1","1000");
		registerName.put("$s2","1001");
		registerName.put("$s3","1010");
		registerName.put("$s4","1011");
		registerName.put("$s5","1100");
		registerName.put("$s6","1101");
		registerName.put("$s7","1110");
		registerName.put("$s8","1111");
		
	}
	public boolean ContainRegister(String regName)
	{
		if(registerName.containsKey(regName))
			return true;
		else
			return false;
		
	}
	
	public String getValueOfRegister(String regName)
	{
		return registerName.get(regName).toString();
	}
}
