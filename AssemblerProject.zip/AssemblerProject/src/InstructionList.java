
import java.util.HashMap;
import java.util.Map;

public class InstructionList {
	private Map<String, String> Rtype;
	private Map<String, String> Itype;
	
	InstructionList()
	{
		Rtype = new HashMap<String, String>();
		Itype = new HashMap<String, String>();
		
		//add opcode and functionality
		Rtype.put("add","1000");
		Rtype.put("sub","1001");
		Rtype.put("and","1010");
		Rtype.put("or","1011");
		Rtype.put("nor","1100");
		
		Itype.put("addi","0100");
		Itype.put("andi","0101");
		Itype.put("ori","0110");
		
		
	}
	
	public boolean containRtypeInstuction(String opcode)
	{
		if(Rtype.containsKey(opcode))
			return true;
		else
			return false;
	}
	public String getValueOfRtypeInstruction(String opcode)
	{
		return Rtype.get(opcode).toString();
	}
	
	public boolean containItypeInstuction(String opcode)
	{
		if(Itype.containsKey(opcode))
			return true;
		else
			return false;
	}
	public String getValueOfItypeInstruction(String opcode)
	{
		return Itype.get(opcode).toString();
	}

}
